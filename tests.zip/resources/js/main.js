$(document).ready(function (e) {

    $('#image').change(function(e){
        let reader = new FileReader();
        reader.onload = (e) => {
            if ($('#image-preview svg').length) {
                $('#image-preview svg').replaceWith(`<img id="image-preview-element" src="${e.target.result}" alt=""/>`);
            } else {
                $("#image-preview-element").attr("src", e.target.result);
            }

        }
        reader.readAsDataURL(this.files[0]);
    });
});

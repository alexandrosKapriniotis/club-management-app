<div class="alert alert-danger" role="alert">
    <?php if($messages): ?>
        <ul class="mb-0">
            <?php $__currentLoopData = (array) $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($message); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\PI4109\Documents\codes\club-management-app\resources\views/partials/form-alert.blade.php ENDPATH**/ ?>